# `Maximal Marginal Relevance`

::: keybert._mmr.mmr
