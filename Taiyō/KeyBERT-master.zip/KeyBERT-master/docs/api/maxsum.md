# `Max Sum Similarity`

::: keybert._maxsum.max_sum_similarity
