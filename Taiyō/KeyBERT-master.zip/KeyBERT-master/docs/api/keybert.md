# `KeyBERT`

::: keybert._model.KeyBERT
